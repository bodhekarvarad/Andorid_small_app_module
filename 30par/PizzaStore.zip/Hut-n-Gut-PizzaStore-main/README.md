
# Hut 'N Gut PizzaStore(Android Application)
<hr>
This app is completely built on Android Studio Using Java Language.

The Pizza Ordering Application “Hut N Gut Pizza” is designed 
to override the problems faced by customer while ordering pizza. 
This application is supported to eliminate and in some cases 
reduce the hardships faced by the existing system. Moreover this 
system is designed for the particular need of the company to 
carry out operations in smooth and effective manner.

Basically this application will come in use when customer will be 
wanting to order pizza etc. according to their interest. The
registered restaurant / café will charge according to the items 
furnished/added in pizza.

<h3>
Functionalities Provided in this Project:- </h3><hr>

  - Provides the searching facilities based on various factors 
    such as Pizza, Order Status.
  - Provides the searching facilities based on various factors 
    such as Pizza, Order Status.
  - Provides easy and reliable user interface where user can 
    see how their customized pizza is going to look.

<h3>Hardware required & technologies used:-</h3>

 - System Requirements:
   - Minimum 4 GB RAM / 32 GB Internal memory android
     phone.
   - Internet Connectivity.
 - Technologies used:
   - Android Studio (For Front-end & Back-end Development).
   - Java Language used for back-end functionalities.
